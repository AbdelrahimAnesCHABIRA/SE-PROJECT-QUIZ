const Chapter = require("../models/chapter_model");

const createChapter = async (req, res) => {
    try {
        const { chapterName } = req.body;
        if (!chapterName) {
            return res.status(400).send({ error: "Chapter name is required" });
        }

        const chapter = new Chapter({ chapterName });
        await chapter.save();
        res.status(201).send(chapter);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
};

const updateChapter = async (req, res) => {
    try {
        const chapter = await Chapter.findById(req.params.id);
        if (!chapter) {
            return res.status(404).send({ error: "Chapter not found" });
        }

        const { chapterName } = req.body;
        if (chapterName) chapter.chapterName = chapterName;

        const updatedChapter = await chapter.save();
        res.status(200).send(updatedChapter);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
};

const deleteChapter = async (req, res) => {
    try {
        const chapter = await Chapter.findById(req.params.id);
        if (!chapter) {
            return res.status(404).send({ error: "Chapter not found" });
        }

        await chapter.remove();
        res.status(200).send(chapter);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
};

const getChapterById = async (req, res) => {
    try {
        const chapter = await Chapter.findById(req.params.id);
        if (!chapter) {
            return res.status(404).send({ error: "Chapter not found" });
        }
        res.status(200).send(chapter);
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
};

module.exports = {
    createChapter,
    updateChapter,
    deleteChapter,
    getChapterById,
};
