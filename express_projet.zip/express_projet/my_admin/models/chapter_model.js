const mongoose = require('mongoose');

const chapterSchema = mongoose.Schema({
    chapterName: {
        type: String,
        required: [true, "Chapter name is required"],
    },
});

module.exports = mongoose.model("Chapter", chapterSchema);
