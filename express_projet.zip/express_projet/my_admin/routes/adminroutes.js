const express = require("express");
const router = express.Router();

// Import controllers
const {
    getModules,
    createModule,
    updateModule,
    deleteModule,
    getModuleById,
} = require("../controllers/module_controller");

const {
    createChapter,
    updateChapter,
    deleteChapter,
    getChapterById,
} = require("../controllers/chapter_controller");

const {
    getQuizzes,
    createQuiz,
    updateQuiz,
    deleteQuiz,
    getQuizById,
} = require("../controllers/quiz_controller");

const {
    getQuestions,
    createQuestion,
    updateQuestion,
    deleteQuestion,
    getQuestionById,
} = require("../controllers/question_controller");

// Quiz Routes
router.route("/quizzes")
    .get(getQuizzes)
    .post(createQuiz);
router.route("/quizzes/:id")
    .get(getQuizById)
    .put(updateQuiz)
    .delete(deleteQuiz);

// Module Routes
router.route("/modules")
    .get(getModules)
    .post(createModule);
router.route("/modules/:id")
    .get(getModuleById)
    .put(updateModule)
    .delete(deleteModule);

// Chapter Routes
router.route("/chapters")
    .post(createChapter);
router.route("/chapters/:id")
    .get(getChapterById)
    .put(updateChapter)
    .delete(deleteChapter);

// Question Routes
router.route("/questions")
    .post(createQuestion);
router.route("/modules/:moduleId/chapters/:chapterId/questions")
    .get(getQuestionsByModuleAndChapter); // Create a new question
router.route("/questions/:id")
    .get(getQuestionById) // Get a question by ID
    .put(updateQuestion) // Update a question
    .delete(deleteQuestion); // Delete a question
router.route("/chapters/:chapterId/questions")
    .get(getQuestions); // Get all questions for a chapter

module.exports = router;
